Backend server to use for the Dataiku Front-end challenge

## Getting Started

```sh
npm install
npm run start
```

Open your browser and checkout the following URLs
* http://localhost:4000/api/columns
* http://localhost:4000/api/data/dividends
